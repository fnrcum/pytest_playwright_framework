class Users:
    """
    TODO: passwords should be retrieved from an environment
    """
    ADMINISTRATOR = {
        "username": "",
        "password": "7&v#DOxQQ!I@"
    }
    ACCOUNT_MANAGER = {
        "username": "",
        "password": "Bk9B$W#b5D3Y"
    }
    MARKETEER = {
        "username": "",
        "password": "eH61A11*1D%@"
    }
    MERCHANDISER = {
        "username": "",
        "password": "V7qxN7H5j]td"
    }
    PLANNER = {
        "username": "",
        "password": "pixZcT5J7}n)"
    }
    READ_ONLY = {
        "username": "",
        "password": "P&k0uM&W!~pd"
    }
    CUSTOMER = {
        "username": "",
        "password": "lc2Fs91GK$lR"
    }