from .common_settings import CommonSettings


class BaseApiTest(CommonSettings):

    pass
